<?php

namespace App\Http\Controllers\Teacher;

use Exception;
use App\Models\Grade;
use App\Models\Student;
use App\Models\package;

use App\Models\OnlineClass;
use Illuminate\Http\Request;
use Jubaer\Zoom\Facades\Zoom;
use Illuminate\Support\Carbon;
use App\Traits\MeetingZoomTrait;
use App\Settings\GeneralSettings;
use App\Http\Controllers\Controller;
use App\Notifications\OnlineSessoinCreated;
use Illuminate\Support\Facades\Notification;
use App\Services\AgoraService;

class OnlineZoomClassesController extends Controller
{

    protected $agoraService;

    public function __construct(AgoraService $agoraService)
    {
        $this->agoraService = $agoraService;
    }


    use MeetingZoomTrait;
    public function index()
    {
        $online_classes = OnlineClass::where('teacher_id', auth('teacher')->user()->id)->get();

        return view('teacher.pages.online_classes.index', compact('online_classes'));
    }

    public function create()
    {
        $grades = Grade::get();
        $packages = package::get();

        return view('teacher.pages.online_classes.add', compact('grades','packages'));
    }
    public function edit($id)
    {
        $onlineClass = OnlineClass::whereId($id)->where('teacher_id', auth('teacher')->id())->firstOrFail();
        $grades = Grade::get();
        $packages = package::get();

        return view('teacher.pages.online_classes.edit', compact('onlineClass', 'grades','packages'));
    }
    public function update(Request $request, $id)
    {
        abort(403);
        // dd(
        //     $meeting
        // );
        $onlineClass = OnlineClass::whereId($id)->where('teacher_id', auth('teacher')->id())->firstOrFail();
        $meeting = $this->updateMeeting($onlineClass->meeting_id, $request);
        // $grades = Grade::get();
        $settings = new GeneralSettings();

        if ($meeting['status']) {

            $startTime = Carbon::parse($request->start_time, auth('teacher')->user()->timezone)->setTimezone($settings->timezone);

            $onlineClass = OnlineClass::create([
                'integration' => true,
                'grade_id' => $request->grade_id,
                'package_id' => $request->package_id,

                'classroom_id' => $request->classroom_id,
                'section_id' => $request->section_id,
                'teacher_id' => auth('teacher')->id(),
                'topic' => $request->topic,
                'start_at' => $startTime,
                'meeting_id' => $meeting['data']['id'],
                'duration' => $meeting['data']['duration'],
                'password' => $meeting['data']['password'],
                'start_url' => $meeting['data']['start_url'],
                'join_url' => $meeting['data']['join_url'],
            ]);

            // $students = Student::where('grade_id', $request->grade_id)
            //     ->where('teacher_id', auth('teacher')->id())
            //     ->where('section_id', $request->section_id)
            //     ->where('classroom_id', $request->classroom_id)
            //     ->get();

            // Notification::send(
            //     $students,
            //     new OnlineSessoinCreated(
            //         auth('teacher')->user()->name,
            //         $onlineClass->start_time
            //     )
            // );

            toastr()->success(trans('messages.success'));
            return redirect()->route('online_sessions.index');
        }
        return to_route('online_sessions.index');
    }

    public function indirectCreate()
    {
        $grades = Grade::get();
        return view('teacher.pages.online_classes.indirect', compact('grades'));
    }

    public function store(Request $request)
    {




        // $meeting = Auth::user()->getUserMeetingInfo()->first();
        // // if(!isset($meeting->id)){
        // //     $name = $request->topic; // that == name in form
        // //     $meetingData = $this->createAgoraProject($name);
        // //     if(isset($meetingData->project->id)){

        // //     }
        // // }

        // $meetingData =[
        //     'channel' => $request->topic,
        //     'start_time' => Carbon::parse($request->start_time)->toIso8601String(),
        //     'duration' => $request->duration,
        //     'timezone' => config('app.timezone'),

        // ];
        $channelName = $request->input('topic');

        $uid = rand(999, 1999); // Unique user ID for the meeting
        // $expireTimeInSeconds = $request->input('duration') * 60; // Duration in seconds
        // $expireTime = now()->addSeconds($expireTimeInSeconds);
    
        // Generate Agora token
        $tokenInfo = $agoraService->generateToken($channelName, $uid, 'publisher', $expireTimeInSeconds);
    
        if (isset($tokenInfo['error'])) {
            return response()->json(['error' => 'Failed to create meeting. Please try again later.'], 500);
        }
    
        // Generate join URL
        $joinUrl = route('join-meeting', ['channelName' => $channelName, 'uid' => $uid]);

        $startUrl = route('start-meeting', ['channelName' => $channelName, 'uid' => $uid]);


    // Save meeting details to database
    $meeting = OnlineClass::create([
        'topic' => $channelName,
        'uid' => $uid,
        'token' => $tokenInfo['token'],
        'duration' => $request->duration,
        'package_id'=> $request->package_id,
        'join_url' => $joinUrl,
        'teacher_id' => auth('teacher')->user()->id,
        'grade_id' => $request->grade_id,
        'classroom_id' => $request->classroom_id,
        'start_url' =>  $startUrl,
   
    ]);


                $students = Student::where('grade_id', $request->grade_id)
                    ->where('teacher_id', auth('teacher')->id())
                    ->where('section_id', $request->section_id)
                    ->where('classroom_id', $request->classroom_id)
                    ->get();

                Notification::send(
                    $students,
                    new OnlineSessoinCreated(
                        auth('teacher')->user()->name,
                        $onlineClass->start_time
                    )
                );

                toastr()->success(trans('messages.success'));
                return redirect()->route('online_sessions.index');




        // $settings = new GeneralSettings();
        // try {
        //     $meeting = $this->createMeeting($request);
        //     if ($meeting['status']) {

        //         $startTime = Carbon::parse($request->start_time, auth('teacher')->user()->timezone)->setTimezone($settings->timezone);

        //         $onlineClass = OnlineClass::create([
        //             'integration' => true,
        //             'grade_id' => $request->grade_id,
        //             'classroom_id' => $request->classroom_id,
        //             'section_id' => $request->section_id,
        //             'teacher_id' => auth('teacher')->user()->id,
        //             'topic' => $request->topic,
        //             'start_at' => $startTime,
        //             'meeting_id' => $meeting['data']['id'],
        //             'duration' => $meeting['data']['duration'],
        //             'password' => $meeting['data']['password'],
        //             'start_url' => $meeting['data']['start_url'],
        //             'join_url' => $meeting['data']['join_url'],
        //         ]);

        //         // $students = Student::where('grade_id', $request->grade_id)
        //         //     ->where('teacher_id', auth('teacher')->id())
        //         //     ->where('section_id', $request->section_id)
        //         //     ->where('classroom_id', $request->classroom_id)
        //         //     ->get();

        //         // Notification::send(
        //         //     $students,
        //         //     new OnlineSessoinCreated(
        //         //         auth('teacher')->user()->name,
        //         //         $onlineClass->start_time
        //         //     )
        //         // );

        //         toastr()->success(trans('messages.success'));
        //         return redirect()->route('online_sessions.index');
        //     }
        // } catch (Exception $e) {
        //     // throw $e;
        //     return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        // }
    }

    public function storeIndirect(Request $request)
    {
       
        try {
            OnlineClass::create([
                'integration' => false,
                'grade_id' => $request->grade_id,
                'classroom_id' => $request->classroom_id,
                'section_id' => $request->section_id,
                'teacher_id' => auth('teacher')->user()->id,
                'meeting_id' => $request->meeting_id,
                'topic' => $request->topic,
                'start_at' => $request->start_time,
                'duration' => $request->duration,
                'password' => $request->password,
                'start_url' => $request->start_url,
                'join_url' => $request->join_url,
            ]);
            toastr()->success(trans('messages.success'));
            return redirect()->route('teacher.online_sessions.index');
        } catch (Exception $e) {
            return redirect()->back()->withErrors(['error' => $e->getMessage()]);
        }

    }


    public function destroy(Request $request, $id)
    {
        try {

            $info = OnlineClass::find($id);

            if ($info->integration) {
                $meeting = Zoom::getMeeting($request->meeting_id);
                if ($meeting['status']) {
                    Zoom::deleteMeeting($request->meeting_id);
                }
            }
            OnlineClass::destroy($id);

            toastr()->success(trans('messages.Delete'));
            return redirect()->route('online_sessions.index');
        } catch (Exception $e) {
            return redirect()->back()->with(['error' => $e->getMessage()]);
        }
    }
}
