<?php

namespace App\Providers;

use Illuminate\Pagination\Paginator;
use Illuminate\Support\ServiceProvider;
use Spatie\Activitylog\Facades\CauserResolver;
use Spatie\Activitylog\Models\Activity;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }


    public function boot()
    {
        Paginator::useBootstrap();

        Activity::saving(function (Activity $activity) {

            $activity->properties = $activity->properties
                ->put('ip', request()->ip())
                ->put('agent', request()->userAgent())
                ->put(
                    'url',
                    request()->fullUrl()
                );
            $causer = optional($activity->causer);
            if ($causer) {
                $activity->properties = $activity->properties
                    ->put('causer_name', $causer->getRawOriginal('name'));
            }
            // $activity->description = trans('app.log_description', [
            //     'event' => $activity->event,
            //     'causer_name' => $causer->name,
            // ]);
        });
    }
}
