<?php return array (
  'calendar' => 'App\\Http\\Livewire\\Calendar',
  'calendar-student' => 'App\\Http\\Livewire\\CalendarStudent',
  'question' => 'App\\Http\\Livewire\\Question',
  'show-question' => 'App\\Http\\Livewire\\ShowQuestion',
);