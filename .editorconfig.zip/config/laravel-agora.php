<?php

return [
    "agora" => [
        "app_id" => env('AGORA_APP_ID', null),
        "app_certificate" => env('AGORA_APP_CERTIFICATE', null),
    ]
];
