<?php

use Illuminate\Database\Seeder;
use Laravelcm\Subscriptions\Models\Feature;
use Laravelcm\Subscriptions\Models\Plan;

class FeatureSeeder extends Seeder
{
    public function run()
    {
        // Feature::create([
        //     'plan_id' => Plan::inRandomOrder()->value('id'),
        //     'name' => 'Questions',
        //     'value' => 5
        // ]);
        // $table->json('name');
        // $table->string('slug')->unique();

        // $table->string('value');

        
        // Feature::create([
        //     'plan_id' => Plan::inRandomOrder()->value('id'),
        //     'name' => 'Lessonss',
        //     'value' => 10
        // ]);
    }
}
